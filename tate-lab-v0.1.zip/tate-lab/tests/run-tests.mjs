import assert from 'node:assert/strict';
import { parseWorkoutText } from '../src/tate-engine/parser.js';
import { classifyWorkout } from '../src/tate-engine/classifier.js';
import { generateCandidates } from '../src/tate-engine/generator.js';

const parsed = parseWorkoutText('6x1000m in 3:00, 2min rest + 5min jog between blocks + 5x200m in 36s, 30sec rest');
const work = parsed.blocks.filter(b => b.kind === 'work');
const between = parsed.blocks.find(b => b.kind === 'inter_block_rest');
assert.equal(work.length, 2);
assert.equal(work[0].reps, 6);
assert.equal(work[0].distanceMeters, 1000);
assert.equal(work[0].targetSecondsPerRep, 180);
assert.equal(work[0].recoverySeconds, 120);
assert.equal(between.durationSeconds, 300);
assert.equal(between.type, 'jog');
assert.equal(work[1].reps, 5);
assert.equal(work[1].targetSecondsPerRep, 36);
assert.equal(work[1].recoverySeconds, 30);

const athlete = { goalEvent: '5K', phase: 'Loading', current5k: '15:00', tolerance: 'high', primaryNeed: 'Threshold', readiness: 84, recentWorkout: '5x1000m in 3:03, 60sec rest' };
const classified = classifyWorkout(parsed, athlete);
assert.ok(classified.some(b => b.kind === 'work' && b.primary));

const candidates = generateCandidates(athlete, {});
assert.ok(candidates.length >= 4);
assert.ok(candidates[0].score >= candidates.at(-1).score);
assert.ok(candidates.every(c => c.score >= 0 && c.score <= 100));

console.log('TATE Lab tests passed:', {
  parsedBlocks: parsed.blocks.length,
  candidates: candidates.length,
  selected: candidates[0].label,
  selectedScore: candidates[0].score.toFixed(1),
});
