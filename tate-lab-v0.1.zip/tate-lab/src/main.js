import {
  ENGINE_VERSION,
  parseWorkoutText,
  classifyWorkout,
  generateCandidates,
  formatCandidate,
  learnPreference,
} from './tate-engine/index.js';
import { loadLearningState, saveLearningState, resetLearningState } from './lab/store.js';
import { sampleAthlete } from './lab/sampleAthletes.js';

const $ = (id) => document.getElementById(id);
let learningState = loadLearningState();
let latestCandidates = [];
let selectedCandidate = null;

$('engine-version').textContent = `Engine ${ENGINE_VERSION}`;

function readAthlete() {
  return {
    goalEvent: $('goal-event').value,
    phase: $('phase').value,
    current5k: $('current-5k').value,
    tolerance: $('tolerance').value,
    primaryNeed: $('primary-need').value,
    readiness: Number($('readiness').value),
    recentWorkout: $('recent-workout').value.trim(),
  };
}

function setAthlete(a) {
  $('goal-event').value = a.goalEvent;
  $('phase').value = a.phase;
  $('current-5k').value = a.current5k;
  $('tolerance').value = a.tolerance;
  $('primary-need').value = a.primaryNeed;
  $('readiness').value = a.readiness;
  $('recent-workout').value = a.recentWorkout;
}

function renderBreakdown(breakdown) {
  return `<div class="score-grid">${Object.entries(breakdown).map(([key, value]) => `
    <div class="score-row"><span>${key}</span><strong>${value >= 0 ? '+' : ''}${value.toFixed(1)}</strong></div>
  `).join('')}</div>`;
}

function renderCandidateCard(candidate, isSelected = false) {
  const blocks = formatCandidate(candidate).map(line => `<div class="block">${line}</div>`).join('');
  return `
    <div class="workout-title">${candidate.label}</div>
    <div><span class="score">${candidate.score.toFixed(1)}</span> / 100</div>
    <div class="meta-line">Family: ${candidate.family} · Learned modifier: ${candidate.learnedModifier.toFixed(3)}</div>
    <div class="meta-line">Progression: ${candidate.progressionReason}</div>
    ${blocks}
    ${isSelected ? renderBreakdown(candidate.breakdown) : ''}
  `;
}

function renderDecision() {
  if (!latestCandidates.length) return;
  selectedCandidate = latestCandidates[0];
  $('decision-status').textContent = `${latestCandidates.length} valid candidates ranked`;
  $('selected-workout').classList.remove('empty');
  $('selected-workout').innerHTML = renderCandidateCard(selectedCandidate, true);
  $('alternatives').innerHTML = latestCandidates.slice(1, 5).map((candidate, index) => `
    <div class="candidate-card" data-index="${index + 1}">
      ${renderCandidateCard(candidate, false)}
    </div>
  `).join('');
  document.querySelectorAll('.candidate-card').forEach(el => {
    el.addEventListener('click', () => {
      const c = latestCandidates[Number(el.dataset.index)];
      $('correction-text').value = formatCandidate(c).join(' + ');
    });
  });
}

function generate() {
  latestCandidates = generateCandidates(readAthlete(), learningState);
  renderDecision();
}

function renderParsed(parsed, classified = []) {
  const workBlocks = classified.filter(b => b.kind === 'work');
  const html = parsed.blocks.map((block, idx) => {
    if (block.kind === 'inter_block_rest') {
      return `<div class="interblock">Between blocks: ${block.durationSeconds ?? '?'} sec · ${block.type}</div>`;
    }
    const classed = workBlocks.shift();
    return `<div class="block">
      <strong>${block.reps}×${block.distanceMeters}m</strong><br>
      target: ${block.targetSecondsPerRep ?? '?'} s/rep · rep recovery: ${block.recoverySeconds ?? '?'} s (${block.recoveryType})<br>
      <span class="meta-line">TATE: ${classed?.primary ?? 'Unknown'}${classed?.secondary?.length ? ` · secondary ${classed.secondary.join(', ')}` : ''}</span>
    </div>`;
  }).join('');
  const warnings = parsed.warnings.length ? `<div class="meta-line">Warnings: ${parsed.warnings.join(' | ')}</div>` : '';
  $('parsed-correction').classList.remove('empty');
  $('parsed-correction').innerHTML = html + warnings;
}

function parseCorrection() {
  const parsed = parseWorkoutText($('correction-text').value);
  const classified = classifyWorkout(parsed, readAthlete());
  renderParsed(parsed, classified);
  return { parsed, classified };
}

function applyCorrection() {
  const text = $('correction-text').value.trim();
  if (!text || !selectedCandidate) return;
  parseCorrection();

  // v1 learning: a coach correction nudges the context-family preference of
  // the selected candidate down slightly and creates/increases a preference
  // for a derived correction family. It does NOT create a hard workout rule.
  learningState = learnPreference(
    learningState,
    selectedCandidate.learningKey,
    -1,
    `Coach preferred a different workout over ${selectedCandidate.label}`,
  );

  const correctionKey = [readAthlete().goalEvent, readAthlete().phase, readAthlete().tolerance, readAthlete().primaryNeed, 'CoachCompositeOrCustom'].join('|');
  learningState = learnPreference(
    learningState,
    correctionKey,
    1,
    text,
  );

  saveLearningState(learningState);
  renderLearning();
  generate();
}

function renderLearning() {
  const entries = Object.entries(learningState);
  if (!entries.length) {
    $('learning-state').innerHTML = '<div class="empty">No learned lab preferences yet.</div>';
    return;
  }
  $('learning-state').innerHTML = `<div class="learning-list">${entries.map(([key, value]) => `
    <div class="learning-item">
      <div class="learning-key">${key}</div>
      <div class="learning-value">${value.modifier.toFixed(3)}</div>
      <div class="meta-line">Evidence: ${value.evidence}${value.notes?.length ? ` · Last note: ${value.notes.at(-1)}` : ''}</div>
    </div>
  `).join('')}</div>`;
}

$('generate').addEventListener('click', generate);
$('parse-correction').addEventListener('click', parseCorrection);
$('apply-correction').addEventListener('click', applyCorrection);
$('load-sample').addEventListener('click', () => { setAthlete(sampleAthlete); generate(); });
$('reset-learning').addEventListener('click', () => {
  resetLearningState();
  learningState = {};
  renderLearning();
  if (latestCandidates.length) generate();
});

renderLearning();
setAthlete(sampleAthlete);
generate();
