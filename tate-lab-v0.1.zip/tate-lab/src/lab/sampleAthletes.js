export const sampleAthlete = {
  goalEvent: '5K',
  phase: 'Loading',
  current5k: '15:00',
  tolerance: 'high',
  primaryNeed: 'Threshold',
  readiness: 84,
  recentWorkout: '5x1000m in 3:03, 60sec rest',
};
